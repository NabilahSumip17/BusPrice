<!DOCTYPE html>
<html >
<head>
   
    <title>Bus Ticket Price Calculator</title>
     <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
     <?php include ('./header.html'); ?>
         
     </body>


<!-- Form design -->
<h1> Bus Ticket Price Calculator </h1>

<form action="BusPriceResult.php" method="post">
    <label for="departure_day">Departure Day:</label>
    <select name="departure_day" id="departure_day">
        <option value=""></option>
        <option value="Saturday">Saturday</option>
        <option value="Sunday">Sunday</option>
        <option value="Monday">Monday</option>
        <option value="Tuesday">Tuesday</option>
        <option value="Wednesday">Wednesday</option>
        <option value="Thursday">Thursday</option>
        <option value="Friday">Friday</option>
    </select>
    <br>
    <label for="departure_time">Departure Time:</label>
    <select name="departure_time" id="departure_time">
        <option value=""></option>
        <option value="7:00">7:00</option>
        <option value="10:00">10:00</option>
        <option value="13:00">13:00</option>
        <option value="16:00">16:00</option>
        <option value="21:00">21:00</option>
    </select>
    <br>
    <input type="submit" name="submit" value="Calculate Ticket Price">
     <a href="BusPrice.php"><input type="button" value="Back To Home"></a>
</form>


</body>
</html>

 <?php include ('./footer.html'); ?>
