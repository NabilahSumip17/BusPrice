<?php
// Function to get ticket price based on departure day and time
function getTicketPrice($departureDay, $departureTime) {
    $ticketPrices = array(
        "Saturday" => [8, 8, 8, 8, 6],
        "Sunday" => [8, 8, 8, 8, 6],
        "Monday" => [6, 6, 6, 6, 5],
        "Tuesday" => [6, 6, 6, 6, 5],
        "Wednesday" => [6, 6, 6, 6, 5],
        "Thursday" => [6, 6, 6, 6, 5],
        "Friday" => [6, 6, 6, 6, 5],
    );

    $dayIndex = array_search($departureDay, array_keys($ticketPrices));
    $timeIndex = array_search($departureTime, ['7:00', '10:00', '13:00', '16:00', '21:00']);

    return $ticketPrices[$departureDay][$timeIndex];
}

// Process form submission
if (isset($_POST['submit'])) {
    $departureDay = isset($_POST['departure_day']) ? $_POST['departure_day'] : "";
    $departureTime = isset($_POST['departure_time']) ? $_POST['departure_time'] : "";

    // Validate input
    if (!empty($departureDay) && !empty($departureTime)) {
        $ticketPrice = getTicketPrice($departureDay, $departureTime);

        // Display output with enhanced styles
        echo "<html>";
        echo "<head>";
        echo "<style>";
        echo "body {";
        echo "  font-family: 'Arial', sans-serif;";
        echo "  background-color: #f4f4f4;";
        echo "  color: #333;";
        echo "  margin: 0;";
        echo "  padding: 0;";
        echo "}";
        echo "h1 {";
        echo "  color: #CC33FF;";
        echo "  text-align: center;";
        echo "}";
        echo "form {";
        echo "  border: 2px solid #CC33FF;";
        echo "  padding: 20px;";
        echo "  max-width: 400px;";
        echo "  margin: 20px auto;";
        echo "  background-color: #fff;";
        echo "  border-radius: 8px;";
        echo "  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);";
        echo "}";
        echo "form input[type=\"button\"] {";
        echo "  background-color: #CC33FF;";
        echo "  color: #fff;";
        echo "  padding: 10px;";
        echo "  border: none;";
        echo "  border-radius: 4px;";
        echo "  cursor: pointer;";
        echo "  width: 100%;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        echo "<h1>Bus Ticket Price</h1>";
        echo "<form>";
        echo "<p><strong>Departure Day:</strong> $departureDay</p>";
        echo "<p><strong>Departure Time:</strong> $departureTime</p>";
        echo "<p><strong>Ticket Price:</strong> RM $ticketPrice</p>";
        echo "<a href=\"BusPrice.php\"><input type=\"button\" value=\"Back To Home\"></a>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
    } else {
        echo "<p>Please fill in both departure day and departure time.</p>";
    }
}
?>

